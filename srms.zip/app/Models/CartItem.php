<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CartItem extends Model {
    protected $table = 'elitevw_sr_cart_items';
    protected $fillable = ['cart_id', 'sku', 'item_name', 'quantity'];
}
