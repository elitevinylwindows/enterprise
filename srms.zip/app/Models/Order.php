<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $table = 'elitevw_sr_orders';

    protected $fillable = [
        'order_number', 'area', 'required_date', 'delivery_date', 'customer_name',
        'short_name', 'internal_order_number', 'comment', 'entered_by', 'entry_date',
        'units', 'number_of_fields', 'total_including', 'currency', 'total_in_row',
        'status_code', 'production', 'edit_status', 'arrival_date', 'project_number',
        'classification', 'production_status_color'
    ];

    protected $dates = [
        'required_date', 'delivery_date', 'entry_date', 'arrival_date'
    ];
}
