<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\CartItem;

class CartController extends Controller
{
    public function index() {
        $carts = Cart::with('items')->get();
        return view('cart.index', compact('carts'));
    }

    public function create() {
        return view('cart.create');
    }

    public function store(Request $request) {
        $cart = Cart::create([
            'cart_number' => $request->cart_number,
            'scanned_by' => auth()->id()
        ]);

        foreach ($request->items as $item) {
            CartItem::create([
                'cart_id' => $cart->id,
                'sku' => $item['sku'],
                'item_name' => $item['item_name'],
                'quantity' => $item['quantity'],
            ]);
        }

        return redirect()->route('cart.index');
    }
}
