
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH /home4/aizwmjte/sr.elitevinylwindows.com/resources/views/admin/content.blade.php ENDPATH**/ ?>