<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('System Settings')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"> <?php echo e(__('System Settings')); ?></li>
<?php $__env->stopSection(); ?>
<?php
    $profile = asset(Storage::url('upload/profile'));
    $settings = settings();
    $activeTab = session('tab', 'footer_column_1');
?>
<?php $__env->startPush('script-page'); ?>
    <script>
        $(document).ready(function() {
        });
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">

                <div class="card-body">
                    <div class="row setting_page_cnt">
                        <div class="col-lg-4">
                            <ul class="nav flex-column nav-tabs account-tabs mb-3" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(empty($activeTab) || $activeTab == 'footer_column_1' ? ' active ' : ''); ?>" id="profile-tab-1" data-bs-toggle="tab"
                                        href="#footer_column_1" role="tab" aria-selected="true">
                                        <div class="d-flex align-items-center">
                                            <div class="flex-shrink-0">
                                                <i class="ti-view-list me-2 f-20"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <h5 class="mb-0"><?php echo e($settings['footer_column_1']); ?></h5>
                                                <small class="text-muted"><?php echo e(__('Footer Column 1 Settings')); ?></small>
                                            </div>
                                        </div>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(empty($activeTab) || $activeTab == 'footer_column_2' ? ' active ' : ''); ?>" id="profile-tab-2" data-bs-toggle="tab" href="#footer_column_2"
                                        role="tab" aria-selected="true">
                                        <div class="d-flex align-items-center">
                                            <div class="flex-shrink-0">
                                                <i class="ti-view-list me-2 f-20"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <h5 class="mb-0"><?php echo e($settings['footer_column_2']); ?></h5>
                                                <small class="text-muted"><?php echo e(__('Footer Column 2 Settings')); ?></small>
                                            </div>
                                        </div>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(empty($activeTab) || $activeTab == 'footer_column_3' ? ' active ' : ''); ?>" id="profile-tab-3" data-bs-toggle="tab" href="#footer_column_3"
                                        role="tab" aria-selected="true">
                                        <div class="d-flex align-items-center">
                                            <div class="flex-shrink-0">
                                                <i class="ti-view-list me-2 f-20"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <h5 class="mb-0"><?php echo e($settings['footer_column_3']); ?></h5>
                                                <small class="text-muted"><?php echo e(__('Footer Column 3 Settings')); ?></small>
                                            </div>
                                        </div>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(empty($activeTab) || $activeTab == 'footer_column_4' ? ' active ' : ''); ?>" id="profile-tab-4" data-bs-toggle="tab" href="#footer_column_4"
                                        role="tab" aria-selected="true">
                                        <div class="d-flex align-items-center">
                                            <div class="flex-shrink-0">
                                                <i class="ti-view-list me-2 f-20"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <h5 class="mb-0"><?php echo e($settings['footer_column_4']); ?></h5>
                                                <small class="text-muted"><?php echo e(__('Footer Column 4 Settings')); ?></small>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-8">
                            <?php if(Gate::check('edit footer')): ?>
                                <div class="tab-content">
                                    <div class="tab-pane  <?php echo e(!empty($activeTab) && $activeTab == 'footer_column_1' ? ' active show ' : ''); ?>" id="footer_column_1" role="tabpanel"
                                        aria-labelledby="footer_column_1">
                                        <?php echo e(Form::model($loginUser, ['route' => ['setting.footer'], 'method' => 'post'])); ?>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('footer_column_1', __('Name'), ['class' => 'form-label'])); ?>

                                                    <?php echo e(Form::text('footer_column_1', $settings['footer_column_1'], ['class' => 'form-control', 'placeholder' => __('Enter your name'), 'required' => 'required'])); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('email', __('Page'), ['class' => 'form-label'])); ?>

                                                    <?php echo Form::select(
                                                        'footer_column_1_pages[]',
                                                        $pages,
                                                        !empty($settings['footer_column_1_pages']) ? json_decode($settings['footer_column_1_pages'], true) : null,
                                                        ['class' => 'form-control hidesearch', 'multiple'],
                                                    ); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('enabled_email', __('Footer Column 1 Enabled'), ['class' => 'form-label'])); ?>

                                                    <div class="form-check form-switch">
                                                        <?php echo e(Form::hidden('footer_column_1_enabled', 'deactive')); ?>

                                                        <?php echo e(Form::checkbox('footer_column_1_enabled', 'active', !empty($settings['footer_column_1_enabled']) && $settings['footer_column_1_enabled'] == 'active' ? true : false, ['class' => 'form-check-input', 'role' => 'switch', 'id' => 'footer_column_1_enabled'])); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-6"></div>
                                            <div class="col-6 text-end">
                                                <input type="hidden" name="tab" value="footer_column_1">
                                                <?php echo e(Form::submit(__('Save'), ['class' => 'btn btn-secondary btn-rounded'])); ?>

                                            </div>
                                        </div>
                                        <?php echo e(Form::close()); ?>

                                    </div>

                                    <div class="tab-pane  <?php echo e(!empty($activeTab) && $activeTab == 'footer_column_2' ? ' active show ' : ''); ?> " id="footer_column_2" role="tabpanel"
                                        aria-labelledby="footer_column_2">
                                        <?php echo e(Form::model($loginUser, ['route' => ['setting.footer'], 'method' => 'post'])); ?>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('footer_column_2', __('Name'), ['class' => 'form-label'])); ?>

                                                    <?php echo e(Form::text('footer_column_2', $settings['footer_column_2'], ['class' => 'form-control', 'placeholder' => __('Enter your name'), 'required' => 'required'])); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('email', __('Page'), ['class' => 'form-label'])); ?>

                                                    <?php echo Form::select(
                                                        'footer_column_2_pages[]',
                                                        $pages,
                                                        !empty($settings['footer_column_2_pages']) ? json_decode($settings['footer_column_2_pages'], true) : null,
                                                        ['class' => 'form-control hidesearch', 'multiple'],
                                                    ); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('footer_column_2_enabled', __('Footer Column 2 Enabled'), ['class' => 'form-label'])); ?>

                                                    <div class="form-check form-switch">
                                                        <?php echo e(Form::hidden('footer_column_2_enabled', 'deactive')); ?>

                                                        <?php echo e(Form::checkbox('footer_column_2_enabled', 'active', !empty($settings['footer_column_2_enabled']) && $settings['footer_column_2_enabled'] == 'active' ? true : false, ['class' => 'form-check-input', 'role' => 'switch', 'id' => 'footer_column_2_enabled'])); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-6"></div>
                                            <div class="col-6 text-end">
                                                <input type="hidden" name="tab" value="footer_column_2">
                                                <?php echo e(Form::submit(__('Save'), ['class' => 'btn btn-secondary btn-rounded'])); ?>

                                            </div>
                                        </div>
                                        <?php echo e(Form::close()); ?>

                                    </div>

                                    <div class="tab-pane  <?php echo e(!empty($activeTab) && $activeTab == 'footer_column_3' ? ' active show ' : ''); ?> " id="footer_column_3" role="tabpanel"
                                        aria-labelledby="footer_column_3">
                                        <?php echo e(Form::model($loginUser, ['route' => ['setting.footer'], 'method' => 'post'])); ?>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('footer_column_3', __('Name'), ['class' => 'form-label'])); ?>

                                                    <?php echo e(Form::text('footer_column_3', $settings['footer_column_3'], ['class' => 'form-control', 'placeholder' => __('Enter your name'), 'required' => 'required'])); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('email', __('Page'), ['class' => 'form-label'])); ?>

                                                    <?php echo Form::select(
                                                        'footer_column_3_pages[]',
                                                        $pages,
                                                        !empty($settings['footer_column_3_pages']) ? json_decode($settings['footer_column_3_pages'], true) : null,
                                                        ['class' => 'form-control hidesearch', 'multiple'],
                                                    ); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('footer_column_3_enabled', __('Footer Column 3 Enabled'), ['class' => 'form-label'])); ?>

                                                    <div class="form-check form-switch">
                                                        <?php echo e(Form::hidden('footer_column_3_enabled', 'deactive')); ?>

                                                        <?php echo e(Form::checkbox('footer_column_3_enabled', 'active', !empty($settings['footer_column_3_enabled']) && $settings['footer_column_3_enabled'] == 'active' ? true : false, ['class' => 'form-check-input', 'role' => 'switch', 'id' => 'footer_column_3_enabled'])); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-6"></div>
                                            <div class="col-6 text-end">
                                                <input type="hidden" name="tab" value="footer_column_3">
                                                <?php echo e(Form::submit(__('Save'), ['class' => 'btn btn-secondary btn-rounded'])); ?>

                                            </div>
                                        </div>
                                        <?php echo e(Form::close()); ?>

                                    </div>

                                    <div class="tab-pane  <?php echo e(!empty($activeTab) && $activeTab == 'footer_column_4' ? ' active show ' : ''); ?> " id="footer_column_4" role="tabpanel"
                                        aria-labelledby="footer_column_4">
                                        <?php echo e(Form::model($loginUser, ['route' => ['setting.footer'], 'method' => 'post'])); ?>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('footer_column_4', __('Name'), ['class' => 'form-label'])); ?>

                                                    <?php echo e(Form::text('footer_column_4', $settings['footer_column_4'], ['class' => 'form-control', 'placeholder' => __('Enter your name'), 'required' => 'required'])); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('email', __('Page'), ['class' => 'form-label'])); ?>

                                                    <?php echo Form::select(
                                                        'footer_column_4_pages[]',
                                                        $pages,
                                                        !empty($settings['footer_column_4_pages']) ? json_decode($settings['footer_column_4_pages'], true) : null,
                                                        ['class' => 'form-control hidesearch', 'multiple'],
                                                    ); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('footer_column_4_enabled', __('Footer Column 4 Enabled'), ['class' => 'form-label'])); ?>

                                                    <div class="form-check form-switch">
                                                        <?php echo e(Form::hidden('footer_column_4_enabled', 'deactive')); ?>

                                                        <?php echo e(Form::checkbox('footer_column_4_enabled', 'active', !empty($settings['footer_column_4_enabled']) && $settings['footer_column_4_enabled'] == 'active' ? true : false, ['class' => 'form-check-input', 'role' => 'switch', 'id' => 'footer_column_4_enabled'])); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-6"></div>
                                            <div class="col-6 text-end">
                                                <input type="hidden" name="tab" value="footer_column_4">
                                                <?php echo e(Form::submit(__('Save'), ['class' => 'btn btn-secondary btn-rounded'])); ?>

                                            </div>
                                        </div>
                                        <?php echo e(Form::close()); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/aizwmjte/sr.elitevinylwindows.com/resources/views/home_pages/footerSetting.blade.php ENDPATH**/ ?>