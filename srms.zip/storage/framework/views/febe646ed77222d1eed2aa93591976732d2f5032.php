<div class="card">
    <div class="card-body">
        <?php echo $page->content; ?>

    </div>
</div>
<?php /**PATH /home4/aizwmjte/sr.elitevinylwindows.com/resources/views/Pages/show.blade.php ENDPATH**/ ?>