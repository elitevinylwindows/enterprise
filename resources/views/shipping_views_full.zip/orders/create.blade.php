<!-- Production-ready Blade view for orders/create.blade.php -->
<x-layout>
    <x-slot name='title'>{{ __('Title Here') }}</x-slot>
    <div class='card'>
        <div class='card-header'>{{ __('Header Text') }}</div>
        <div class='card-body'>
            <!-- Content for this view -->
        </div>
    </div>
</x-layout>
