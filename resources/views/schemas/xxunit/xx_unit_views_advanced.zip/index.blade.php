@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">XX Units</h4>
        <a href="{{ route('xx-unit.create') }}" class="btn btn-primary">+ Add XX Unit</a>
    </div>
    <div class="card">
        <div class="card-body">
            <table id="datatable" class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Schema ID</th>
                        <th>Retrofit</th>
                        <th>Nailon</th>
                        <th>Block</th>
                        <th>LE3 Clr</th>
                        <th>LE3 Lam</th>
                        <th>Clr Temp</th>
                        <th>LE3 Clr + LE3</th>
                        <th>2LE3 + 1CLR Temp</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($xxunits as $unit)
                    <tr>
                        <td>{{ $unit->id }}</td>
                        <td>{{ $unit->schema_id }}</td>
                        <td>{{ $unit->retrofit }}</td>
                        <td>{{ $unit->nailon }}</td>
                        <td>{{ $unit->block }}</td>
                        <td>{{ $unit->le3_clr }}</td>
                        <td>{{ $unit->le3_lam }}</td>
                        <td>{{ $unit->clr_temp }}</td>
                        <td>{{ $unit->le3_clr_le3 }}</td>
                        <td>{{ $unit->twole3_oneclr_temp }}</td>
                        <td>
                            <a href="{{ route('xx-unit.edit', $unit->id) }}" class="btn btn-sm btn-warning">Edit</a>
                            <form action="{{ route('xx-unit.destroy', $unit->id) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    $(document).ready(function () {
        $('#datatable').DataTable();
    });
</script>
@endpush
