@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <h4>Edit XX Unit</h4>
    <div class="card">
        <div class="card-body">
            <form action="{{ route('xx-unit.update', $xxunit->id) }}" method="POST">
                @csrf
                @method('PUT')
                @include('schemas.xx-unit.form', ['xxunit' => $xxunit])
                <button type="submit" class="btn btn-primary mt-3">Update</button>
            </form>
        </div>
    </div>
</div>
@endsection
