@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <h4>Create XX Unit</h4>
    <div class="card">
        <div class="card-body">
            <form action="{{ route('xx-unit.store') }}" method="POST">
                @csrf
                @include('schemas.xx-unit.form')
                <button type="submit" class="btn btn-success mt-3">Save</button>
            </form>
        </div>
    </div>
</div>
@endsection
